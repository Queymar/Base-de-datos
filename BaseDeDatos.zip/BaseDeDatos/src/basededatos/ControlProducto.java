package basededatos;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;
import util.Configuracion;

public class ControlProducto {
    public static boolean agregar(String codigo, String nombre,
            String cantidad, String precio, String categoria){
        String sql = "INSERT INTO producto(codigo, nombre, cantidad, precio, categoria) "
                + "VALUES('"+codigo+"', '"+nombre+"', '"+cantidad+"', '"+precio+"', '"+categoria+"')";
        return Configuracion.conexion.ejecutaSQL(sql);
    }
    
    public static boolean editar(String codigo, String nombre,
            String cantidad, String precio, String categoria){
        String sql = "UPDATE producto SET "
                + "codigo='"+codigo+"', nombre='"+nombre+"', cantidad='"+cantidad+
                "', precio='"+precio+"', categoria='"+categoria+
                "' WHERE codigo='"+Configuracion.ID+"'";
        return Configuracion.conexion.ejecutaSQL(sql);
    }
    
    public static boolean eliminar(){
        String sql = "DELETE FROM producto WHERE codigo='"+Configuracion.ID+"'";
        return Configuracion.conexion.ejecutaSQL(sql);
    }
    
    public static ResultSet mostrar(){
        ResultSet rs = null;
        String sql = "SELECT * FROM producto ORDER BY nombre ASC";
        rs = Configuracion.conexion.consultaSQL(sql);
        return rs;
    }
    
    public static int getRows(){
        ResultSet rs = null;
        String sql = "SELECT COUNT(*) AS cantidad FROM producto";
        rs = Configuracion.conexion.consultaSQL(sql);
        try {
            while(rs.next()){
                return rs.getInt("cantidad");
            }
        } catch (SQLException ex) {
            Logger.getLogger(ControlProducto.class.getName()).log(Level.SEVERE, null, ex);
        }
        return 0;
    }
    
    public static ResultSet producto(){
        ResultSet rs = null;
        String sql = "SELECT * FROM producto WHERE codigo='"+Configuracion.ID+"'";
        rs = Configuracion.conexion.consultaSQL(sql);       
        return rs;
    }
       
}
