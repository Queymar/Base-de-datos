package basededatos;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;
import util.Configuracion;

public class ControlProveedor {
    public static boolean agregar(String rfc, String nombre,
            String direccion, String telefono){
        String sql = "INSERT INTO proveedor(rfc, nombre, direccion, telefono) "
                + "VALUES('"+rfc+"', '"+nombre+"', '"+direccion+"', '"+telefono+"')";
        return Configuracion.conexion.ejecutaSQL(sql);
    }
    
    public static boolean editar(String rfc, String nombre,
            String direccion, String telefono){
        String sql = "UPDATE proveedor SET "
                + "rfc='" + rfc + "', nombre='" + nombre+"', direccion='" + direccion +
                "', telefono='" + telefono + "' WHERE rfc='" + Configuracion.ID + "'";
        return Configuracion.conexion.ejecutaSQL(sql);
    }
    
    public static boolean eliminar(){
        String sql = "DELETE FROM proveedor WHERE rfc='"+Configuracion.ID+"'";
        return Configuracion.conexion.ejecutaSQL(sql);
    }
    
    public static ResultSet mostrar(){
        ResultSet rs = null;
        String sql = "SELECT * FROM proveedor ORDER BY nombre ASC";
        rs = Configuracion.conexion.consultaSQL(sql);
        return rs;
    }
    
    public static int getRows(){
        ResultSet rs = null;
        String sql = "SELECT COUNT(*) AS cantidad FROM proveedor";
        rs = Configuracion.conexion.consultaSQL(sql);
        try {
            while(rs.next()){
                return rs.getInt("cantidad");
            }
        } catch (SQLException ex) {
            Logger.getLogger(ControlProveedor.class.getName()).log(Level.SEVERE, null, ex);
        }
        return 0;
    }
    
    public static ResultSet proveedor(){
        ResultSet rs = null;
        String sql = "SELECT * FROM proveedor WHERE rfc='"+Configuracion.ID+"'";
        rs = Configuracion.conexion.consultaSQL(sql);       
        return rs;
    }
       
}
