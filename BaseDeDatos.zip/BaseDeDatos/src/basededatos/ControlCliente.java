package basededatos;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;
import util.Configuracion;

public class ControlCliente {
    public static boolean agregar(String rfc, String nombre, String apellidos,
            String edad, String direccion, String telefono){
        String sql = "INSERT INTO cliente(rfc, nombre, apellidos, edad, direccion, telefono) "
                + "VALUES('"+rfc+"', '"+nombre+"', '"+apellidos+"', '"+edad+"', '"+direccion+"', '"+telefono+"')";
        return Configuracion.conexion.ejecutaSQL(sql);
    }
    
    public static boolean editar(String rfc, String nombre, String apellidos,
            String edad, String direccion, String telefono){
        String sql = "UPDATE cliente SET "
                + "rfc='"+rfc+"', nombre='"+nombre+"', apellidos='"+apellidos+"', edad='"+edad+
                "', direccion='"+direccion+"', telefono='"+telefono+
                "' WHERE rfc='"+Configuracion.ID+"'";
        return Configuracion.conexion.ejecutaSQL(sql);
    }
    
    public static boolean eliminar(){
        String sql = "DELETE FROM cliente WHERE rfc='"+Configuracion.ID+"'";
        return Configuracion.conexion.ejecutaSQL(sql);
    }
    
    public static ResultSet mostrar(){
        ResultSet rs = null;
        String sql = "SELECT * FROM cliente ORDER BY nombre ASC";
        rs = Configuracion.conexion.consultaSQL(sql);
        return rs;
    }
    
    public static int getRows(){
        ResultSet rs = null;
        String sql = "SELECT COUNT(*) AS cantidad FROM cliente";
        rs = Configuracion.conexion.consultaSQL(sql);
        try {
            while(rs.next()){
                return rs.getInt("cantidad");
            }
        } catch (SQLException ex) {
            Logger.getLogger(ControlCliente.class.getName()).log(Level.SEVERE, null, ex);
        }
        return 0;
    }
    
    public static ResultSet cliente(){
        ResultSet rs = null;
        String sql = "SELECT * FROM cliente WHERE rfc='"+Configuracion.ID+"'";
        rs = Configuracion.conexion.consultaSQL(sql);       
        return rs;
    }
       
}
