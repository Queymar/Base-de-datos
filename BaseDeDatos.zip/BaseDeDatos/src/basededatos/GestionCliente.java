package basededatos;

import java.awt.Color;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;
import util.Configuracion;

public class GestionCliente extends javax.swing.JDialog {

    /**
     * Creates new form GestionProducto
     */
    public GestionCliente(java.awt.Frame parent, boolean modal) {
        super(parent, modal);
        initComponents();
        inicio();
        setLocationRelativeTo(parent);
        this.setVisible(true);                
    }
    
    private void inicio(){
        title.setText(Configuracion.TITULO);
        switch(Configuracion.ACCION){
            case 1: panel.setBackground(new Color(0,204,51)); break;
            case 2: panel.setBackground(new Color(102,102,255)); rellenaCampos(); break;
            case 3: panel.setBackground(new Color(255,51,51));
                    rellenaCampos(); desactivaCampos(); break;            
        }
    }
    
    private void agregarCliente() {
        String valida = validaCampos();
        if (valida.length() == 0) {
            boolean ejecuta = ControlCliente.agregar(
                    _rfc.getText(),
                    _nombre.getText(),
                    _apellidos.getText(),
                    _edad.getText(),
                    _direccion.getText(),
                    _telefono.getText());
            if (ejecuta) {
                JOptionPane.showMessageDialog(this, "Cliente Agregado", "Info", JOptionPane.INFORMATION_MESSAGE);
                dispose();
            } else {
                JOptionPane.showMessageDialog(this, "Error al agregar Cliente", "Error", JOptionPane.ERROR_MESSAGE);
            }
        }else{
            JOptionPane.showMessageDialog(this, valida, "Advertencia", JOptionPane.WARNING_MESSAGE);
        }
    }
    
    private void editarCliente() {
        String valida = validaCampos();
        if (valida.length() == 0) {
            boolean ejecuta = ControlCliente.editar(
                    _rfc.getText(),
                    _nombre.getText(),
                    _apellidos.getText(),
                    _edad.getText(),
                    _direccion.getText(),
                    _telefono.getText());
            if (ejecuta) {
                JOptionPane.showMessageDialog(this, "Cliente Actualizado Correctamente", "Info", JOptionPane.INFORMATION_MESSAGE);
                dispose();
            } else {
                JOptionPane.showMessageDialog(this, "Error al actualizar cliente", "Error", JOptionPane.ERROR_MESSAGE);
            }
        }else{
            JOptionPane.showMessageDialog(this, valida, "Advertencia", JOptionPane.WARNING_MESSAGE);
        }
    }
    
    private void eliminarCliente(){
        boolean ejecuta = ControlCliente.eliminar();
        if (ejecuta) {
                JOptionPane.showMessageDialog(this, "Cliente Eliminado Correctamente", "Info", JOptionPane.INFORMATION_MESSAGE);
                dispose();
            } else {
                JOptionPane.showMessageDialog(this, "Error al eliminar cliente", "Error", JOptionPane.ERROR_MESSAGE);
            }
    }
    
    private String validaCampos(){
        String msj = "";
        if( !_rfc.getText().matches("[A-Za-z0-9]{12,13}") )
            msj += "El RFC solo acepta letras y números entre 12 Y 13 caracteres\n";        
        if( !_nombre.getText().matches("[A-Za-z0-9 ]{4,50}") )
            msj += "El nombre solo acepta letras y números entre 4 y 50 caracteres\n";
        if( !_apellidos.getText().matches("[A-Za-z0-9 ]{4,50}") )
            msj += "El apellido solo acepta letras y números entre 4 y 50 caracteres\n";        
        if( !_edad.getText().matches("[0-9 ]{2,3}") )
            msj += "La edad solo acepta números enteros de máximo 3 cifras\n";
        if( !_direccion.getText().matches("([A-Za-z0-9]| ){4,50}") )
            msj += "La dirección solo acepta letras y números entre 4 y 50 caracteres\n";
        if( !_telefono.getText().matches("[0-9]{10}") )
            msj += "El teléfono debe tener 10 caracteres numéricos\n";
                
        return msj;
    }
    
    private void rellenaCampos(){
        ResultSet rs = ControlCliente.cliente();        
        try {
            rs.next();
            _rfc.setText(rs.getString("rfc"));
            _nombre.setText(rs.getString("nombre"));
            _apellidos.setText(rs.getString("apellidos"));
            _edad.setText(rs.getInt("edad")+"");
            _direccion.setText(rs.getString("direccion")+"");
            _telefono.setText(rs.getString("telefono"));
        } catch (SQLException ex) {
            Logger.getLogger(GestionCliente.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    
    public void desactivaCampos(){
        _rfc.setEditable(false);
        _nombre.setEditable(false);
        _edad.setEditable(false);
        _direccion.setEditable(false);
        _telefono.setEditable(false);
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        panel = new javax.swing.JPanel();
        title = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        _rfc = new javax.swing.JTextField();
        btn_accept = new javax.swing.JButton();
        btn_cancel = new javax.swing.JButton();
        _nombre = new javax.swing.JTextField();
        _edad = new javax.swing.JTextField();
        _direccion = new javax.swing.JTextField();
        _telefono = new javax.swing.JTextField();
        jLabel7 = new javax.swing.JLabel();
        _apellidos = new javax.swing.JTextField();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);

        panel.setBackground(new java.awt.Color(0, 204, 51));

        title.setFont(new java.awt.Font("Tahoma", 1, 24)); // NOI18N
        title.setForeground(new java.awt.Color(255, 255, 255));
        title.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        title.setText("TÍTULO");

        jLabel2.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        jLabel2.setForeground(new java.awt.Color(255, 255, 255));
        jLabel2.setText("RFC:");

        jLabel3.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        jLabel3.setForeground(new java.awt.Color(255, 255, 255));
        jLabel3.setText("Nombre:");

        jLabel4.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        jLabel4.setForeground(new java.awt.Color(255, 255, 255));
        jLabel4.setText("Edad:");

        jLabel5.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        jLabel5.setForeground(new java.awt.Color(255, 255, 255));
        jLabel5.setText("Dirección:");

        jLabel6.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        jLabel6.setForeground(new java.awt.Color(255, 255, 255));
        jLabel6.setText("Teléfono:");

        _rfc.setBackground(new java.awt.Color(255, 255, 204));
        _rfc.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        _rfc.setPreferredSize(new java.awt.Dimension(6, 27));
        _rfc.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                _rfcActionPerformed(evt);
            }
        });

        btn_accept.setBackground(new java.awt.Color(0, 153, 255));
        btn_accept.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        btn_accept.setForeground(new java.awt.Color(255, 255, 255));
        btn_accept.setText("Aceptar");
        btn_accept.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_acceptActionPerformed(evt);
            }
        });

        btn_cancel.setBackground(new java.awt.Color(255, 51, 51));
        btn_cancel.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        btn_cancel.setForeground(new java.awt.Color(255, 255, 255));
        btn_cancel.setText("Cancelar");
        btn_cancel.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_cancelActionPerformed(evt);
            }
        });

        _nombre.setBackground(new java.awt.Color(255, 255, 204));
        _nombre.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        _nombre.setPreferredSize(new java.awt.Dimension(6, 27));
        _nombre.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                _nombreActionPerformed(evt);
            }
        });

        _edad.setBackground(new java.awt.Color(255, 255, 204));
        _edad.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        _edad.setPreferredSize(new java.awt.Dimension(6, 27));
        _edad.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                _edadActionPerformed(evt);
            }
        });

        _direccion.setBackground(new java.awt.Color(255, 255, 204));
        _direccion.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        _direccion.setPreferredSize(new java.awt.Dimension(6, 27));
        _direccion.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                _direccionActionPerformed(evt);
            }
        });

        _telefono.setBackground(new java.awt.Color(255, 255, 204));
        _telefono.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        _telefono.setPreferredSize(new java.awt.Dimension(6, 27));
        _telefono.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                _telefonoActionPerformed(evt);
            }
        });

        jLabel7.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        jLabel7.setForeground(new java.awt.Color(255, 255, 255));
        jLabel7.setText("Apellidos:");

        _apellidos.setBackground(new java.awt.Color(255, 255, 204));
        _apellidos.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        _apellidos.setPreferredSize(new java.awt.Dimension(6, 27));
        _apellidos.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                _apellidosActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout panelLayout = new javax.swing.GroupLayout(panel);
        panel.setLayout(panelLayout);
        panelLayout.setHorizontalGroup(
            panelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(title, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addGroup(panelLayout.createSequentialGroup()
                .addGap(39, 39, 39)
                .addGroup(panelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(panelLayout.createSequentialGroup()
                        .addComponent(jLabel7)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(_apellidos, javax.swing.GroupLayout.PREFERRED_SIZE, 124, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(panelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                        .addGroup(javax.swing.GroupLayout.Alignment.LEADING, panelLayout.createSequentialGroup()
                            .addComponent(btn_accept)
                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(btn_cancel))
                        .addGroup(javax.swing.GroupLayout.Alignment.LEADING, panelLayout.createSequentialGroup()
                            .addGroup(panelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                .addComponent(jLabel2)
                                .addComponent(jLabel3)
                                .addComponent(jLabel4)
                                .addComponent(jLabel5)
                                .addComponent(jLabel6))
                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                            .addGroup(panelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                .addComponent(_rfc, javax.swing.GroupLayout.PREFERRED_SIZE, 124, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addComponent(_nombre, javax.swing.GroupLayout.PREFERRED_SIZE, 124, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addComponent(_edad, javax.swing.GroupLayout.PREFERRED_SIZE, 124, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addComponent(_direccion, javax.swing.GroupLayout.PREFERRED_SIZE, 124, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addComponent(_telefono, javax.swing.GroupLayout.PREFERRED_SIZE, 124, javax.swing.GroupLayout.PREFERRED_SIZE)))))
                .addContainerGap(52, Short.MAX_VALUE))
        );
        panelLayout.setVerticalGroup(
            panelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(panelLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(title, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addGroup(panelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(panelLayout.createSequentialGroup()
                        .addComponent(jLabel2)
                        .addGap(16, 16, 16))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, panelLayout.createSequentialGroup()
                        .addComponent(_rfc, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(14, 14, 14)))
                .addGroup(panelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel3)
                    .addComponent(_nombre, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 11, Short.MAX_VALUE)
                .addGroup(panelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel7)
                    .addComponent(_apellidos, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(panelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel4)
                    .addComponent(_edad, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(panelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel5)
                    .addComponent(_direccion, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(panelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel6)
                    .addComponent(_telefono, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(panelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btn_accept)
                    .addComponent(btn_cancel))
                .addGap(20, 20, 20))
        );

        getContentPane().add(panel, java.awt.BorderLayout.CENTER);

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void _rfcActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event__rfcActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event__rfcActionPerformed

    private void _nombreActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event__nombreActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event__nombreActionPerformed

    private void _edadActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event__edadActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event__edadActionPerformed

    private void _direccionActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event__direccionActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event__direccionActionPerformed

    private void _telefonoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event__telefonoActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event__telefonoActionPerformed

    private void btn_acceptActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_acceptActionPerformed
        // TODO add your handling code here:
        switch(Configuracion.ACCION){
            case 1: agregarCliente(); break;
            case 2: editarCliente(); break;
            case 3: eliminarCliente(); break;
        }
    }//GEN-LAST:event_btn_acceptActionPerformed

    private void btn_cancelActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_cancelActionPerformed
        // TODO add your handling code here:
        dispose();
    }//GEN-LAST:event_btn_cancelActionPerformed

    private void _apellidosActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event__apellidosActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event__apellidosActionPerformed

    
    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JTextField _apellidos;
    private javax.swing.JTextField _direccion;
    private javax.swing.JTextField _edad;
    private javax.swing.JTextField _nombre;
    private javax.swing.JTextField _rfc;
    private javax.swing.JTextField _telefono;
    private javax.swing.JButton btn_accept;
    private javax.swing.JButton btn_cancel;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JPanel panel;
    private javax.swing.JLabel title;
    // End of variables declaration//GEN-END:variables
}
