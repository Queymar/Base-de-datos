package util;


public class Configuracion {
    public static String ID = "";
    public static String TITULO = "";
    public static int ACCION = 1;
    public static MySQL conexion = null;
    
}
