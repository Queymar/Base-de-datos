package util;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;

public class MySQL {
    private final String BD = "topicos";
    private final String USER = "root"; //usuario mysql
    private final String PASS = "1234"; //contraseña mysql
    private final String SERVER = "localhost";
    protected Connection conexion;
    
    public MySQL(){        
        String zonaHoraria = "?useUnicode=true&useJDBCCompliantTimezoneShift=true&useLegacyDatetimeCode=false&serverTimezone=UTC";
        String url = "jdbc:mysql://"+SERVER+"/"+BD+zonaHoraria;
        
        try{
            Class.forName("com.mysql.cj.jdbc.Driver").newInstance();
            conexion = DriverManager.getConnection(url,USER,PASS);            
        }catch(Exception e){
            System.out.println(e);
            JOptionPane.showMessageDialog(null, "Error al conectarse al servidor");
            System.exit(0);
        }                
    }
    
    public boolean ejecutaSQL(String sql){
        try{
            Statement consulta = conexion.createStatement();
            consulta.executeUpdate(sql);
            consulta.close();
            return true;
        }catch(SQLException ex){
            Logger.getLogger(MySQL.class.getName()).log(Level.SEVERE, null, ex);
            return false;
        }
    }
    
    public ResultSet consultaSQL( String sql ){
        ResultSet rs = null;
        try{
            Statement consulta = conexion.createStatement();
            rs = consulta.executeQuery(sql);
        }catch(SQLException exc){
            Logger.getLogger(MySQL.class.getName()).log(Level.SEVERE, null, exc);         
        }
        return rs;
    }
    
    public Connection getConexion(){
        return conexion;
    }
    
    public void desconectar(){
        conexion = null;
    }
}
